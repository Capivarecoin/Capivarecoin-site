//========chart initialize
var chartDom = document.getElementById('token-allocation');
var myChart = echarts.init(chartDom, 'dark');
var option;

option = {

    tooltip: {
        trigger: 'item',
        formatter: '{a} <br/>{b} : {c} ({d}%)'
    },
    backgroundColor: 'transparent',
    toolbox: {
        show: true,
        feature: {
            mark: {
                show: true
            },
            dataView: {
                show: true,
                readOnly: false
            },
            restore: {
                show: true
            },
            saveAsImage: {
                show: true
            }
        },

    },
    textStyle: {
        color: 'white',
        fontSize: '16px',
        fontWeight: '700',
    },
    series: [{
        name: 'Token Allocation',
        type: 'pie',
        radius: [20, 140],
        center: ['50%', '50%'],
        roseType: 'area',
        itemStyle: {
            borderRadius: 5
        },

        data: [{
                value: 30,
                name: 'Blockchain'
            },
            {
                value: 28,
                name: 'Research'
            },
            {
                value: 26,
                name: 'Reward'
            },
            {
                value: 24,
                name: 'Token Sale'
            },
            {
                value: 22,
                name: 'Decentralize'
            }
        ]
    }]
};

option && myChart.setOption(option);