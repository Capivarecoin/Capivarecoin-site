//========= chart 2
var chartDom = document.getElementById('token-allocation-2');
var myChart = echarts.init(chartDom, 'dark');
var option;

option = {
    tooltip: {
        trigger: 'item'
    },
    color: [
        '#149E11',
        '#9656E7',
        '#F28531',
        '#3C5DD0',
        '#EF8181',
        '#6e7074',
        '#546570',
        '#c4ccd3'
    ],
    backgroundColor: 'transparent',
    legend: {
        orient: 'vertical',
        right: 10,
        bottom: 'center',
        right: 'right',
    },
    series: [{
        name: 'Sale Proceed Allocation',
        type: 'pie',
        radius: ['0%', '60%'],
        avoidLabelOverlap: true,
        roseType: 'area',
        center: ['30%', '50%'],
        label: {
            show: false,
            position: 'center'
        },
        labelLine: {
            show: true
        },
        data: [{
                value: 900,
                name: 'Development'
            },
            {
                value: 850,
                name: 'Token Sale'
            },
            {
                value: 800,
                name: 'Administrator'
            },
            {
                value: 750,
                name: 'Mining Facilites'
            },
            {
                value: 810,
                name: 'Marketing'
            }
        ]
    }]
};
option && myChart.setOption(option);